# Readme

本项目为前后端分离项目。

请使用idea分别打开libary_front文件夹和library_back文件夹，进入工程。

然后在library_back的application.yaml中设置数据库连接需要的信息，包括账号密码等。

用命令行进入前端文件夹，输入npm i并运行。（请自行安装npm）

点击运行分别运行前端和后端项目，然后访问在浏览器中访问http://localhost:5173/，运行项目。

如果要进行测试，请进入library_back工程中，在test/java/lee/library_back下运行测试类LibraryTest（点击测试按钮即可），由于目录已经改变，请不要用原来的mvn命令，

