package lee.library_back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
