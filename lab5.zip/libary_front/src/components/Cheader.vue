<template>
  <div class="wrapper">
    <h1>L-Library</h1>
  </div>
</template>

<script>
export default {
  name: "Cheader"
}
</script>

<style scoped>
  .wrapper{
    width: 100%;
    height: 10vh;
    text-align: center;
  }
  .wrapper h1{
    font-size: 2.5rem;
  }
</style>